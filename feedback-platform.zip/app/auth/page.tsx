import { AuthForm } from "@/components/auth/auth-form"

export default function AuthPage() {
  return <AuthForm />
}
